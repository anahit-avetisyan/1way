<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Tables</title>

    <!-- Fontfaces CSS-->
    <link href="admincss/font-face.css" rel="stylesheet" media="all">
    <link href="adminvendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="adminvendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="adminvendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="adminvendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="adminvendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="adminvendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="admincss/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">
    <!-- HEADER MOBILE-->
    <header class="header-mobile d-block d-lg-none">
        <div class="header-mobile__bar">
            <div class="container-fluid">
                <div class="header-mobile-inner">
                    <a class="logo" href="index.html">
                        <img src="images/icon/logo.png" alt="CATEGORY" />
                    </a>
                    <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                    </button>
                </div>
            </div>
        </div>
        <nav class="navbar-mobile">
            <div class="container-fluid">
                <ul class="navbar-mobile__list list-unstyled">
                    <li class="has-sub">
                        <a class="js-arrow" href="#"><i class="fas fa-tachometer-alt"></i>Category</a>
                        <a class="js-arrow" href=""><i class="fas fa-tachometer-alt"></i>AddCategory</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- END HEADER MOBILE-->

    <!-- MENU SIDEBAR-->
    <aside class="menu-sidebar d-none d-lg-block">
        <div class="logo">
            <a href="index.html">
                <img src="images/icon/logo.png" alt="Cool Admin" />
            </a>
        </div>
        <div class="menu-sidebar__content js-scrollbar1">
            <nav class="navbar-sidebar">
                <ul class="list-unstyled navbar__list">
                    <li class="has-sub">
                        <a class="js-arrow" href="{{route('category.create')}}"><i class="fas fa-tachometer-alt"></i>Ավելացնել Կատեգորիա</a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>
    <!-- END MENU SIDEBAR-->

    <!-- PAGE CONTAINER-->
    <div class="page-container">
        <!-- HEADER DESKTOP-->

        <!-- END HEADER DESKTOP-->

        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-9" style="max-width: 100%!important;">
                            <div class="table-responsive table--no-card m-b-30">
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                    <tr>
                                        <th>N°Համարը</th>
                                        <th>Անվանումը</th>
                                        <th>pashton</th>
                                        <th>email</th>
                                        <th>Ստեղծվել է</th>
                                        <th>Ձևապոխվել է</th>
                                        <th>Ձևապոխել</th>
                                        <th>Ջնջել</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @isset($user)
                                        @foreach($user as $users)
                                            <tr>
                                                <td>{{$users->id}}</td>
                                                <td>{{$users->name}}</td>
                                                <td>{{$users->usertype}}</td>
                                                <td>{{$users->email}}</td>
                                                <td>{{$users->created_at}}</td>
                                                <td>{{$users->updated_at}}</td>
                                                <td >
                                                    <form  action="{{route('user.edit',$users ->id)}}" method="get" >
                                                        <button type="submit" data-toggle="tooltip" title="Delete sub-category"
                                                                class="btn btn-danger btn-sm" style="height:25px;width: 25px;border-color: #0b2e13;background-color: #1c7430;text-align: center">
                                                            <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                                <td class="delete-brn-td">
                                                    <form action="{{route('user.destroy',$users->id)}}} " method="post">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button type="submit " class="btn btn-danger" >X
                                                            <i class="fa fa-trash-o" aria-hidden="true" ></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @endisset
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Jquery JS-->
<script src="adminvendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap JS-->
<script src="adminvendor/bootstrap-4.1/popper.min.js"></script>
<script src="adminvendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="adminvendor/slick/slick.min.js">
</script>
<script src="adminvendor/wow/wow.min.js"></script>
<script src="adminvendor/animsition/animsition.min.js"></script>
<script src="adminvendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="adminvendor/counter-up/jquery.waypoints.min.js"></script>
<script src="adminvendor/counter-up/jquery.counterup.min.js">
</script>
<script src="adminvendor/circle-progress/circle-progress.min.js"></script>
<script src="adminvendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="adminvendor/chartjs/Chart.bundle.min.js"></script>
<script src="adminvendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="adminjs/main.js"></script>

</body>

</html>
<!-- end document-->
